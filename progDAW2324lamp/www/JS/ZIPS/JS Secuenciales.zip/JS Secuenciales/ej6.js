let galon = parseInt(prompt("galon"));;
let litros = parseInt(prompt("litros"));;

let resultado = galon * litros;

console.log(resultado);
