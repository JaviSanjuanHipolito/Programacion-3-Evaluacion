
let base = parseInt(prompt("base:"));
let altura = parseInt(prompt("altura"));
resultado = (base * altura);
window.alert(resultado);
