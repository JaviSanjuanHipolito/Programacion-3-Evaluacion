let altura = parseInt(prompt("altura"));;
let ancho = parseInt(prompt("ancho"));;

let resultado = altura * ancho;

console.log(resultado);